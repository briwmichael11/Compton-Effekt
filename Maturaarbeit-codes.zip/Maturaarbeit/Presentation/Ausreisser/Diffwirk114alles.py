import math

import numpy as np
from scipy.optimize import curve_fit
import matplotlib.pyplot as plt

# Gauss-Funktion für den Fit
def func(x, a, x0, sigma):
    return a * np.exp(-(x - x0)**2 / (2 * sigma**2))

# Lineare Umrechnungsfunktion für X-Werte (Zeilennummern)
a_lin = 0.8919940215753929
b_lin = -31.934619491620538

def transform_x(x):
    return a_lin * x + b_lin

def inverse_transform_x(x_trans):
    return (x_trans - b_lin) / a_lin

# Pfad zur .Spe Datei
dateipfad = "114_diff.Wirkungsgrad - Edit.Spe"

# Bereich wählen: Start- und Endzeile
startzeile = 15155  # erste Zeile = 1
endzeile = 15180  # letzte Zeile, inklusive

y_values = []
x_original = []  # Originale Zeilennummern für Plot
x_transformed = []  # Transformierte Werte für Fit

with open(dateipfad, 'r') as f:
    for i, line in enumerate(f, start=1):
        if i < startzeile or i > endzeile:
            continue
        line = line.strip()
        if not line:
            continue
        for val in line.split():
            y_values.append(float(val))
            x_original.append(i)  # Unveränderte Zeilennummer für Anzeige
            x_transformed.append(transform_x(i))  # Transformiert für Fit

x_orig = np.array(x_original, dtype=float)
x_fit = np.array(x_transformed, dtype=float)
y = np.array(y_values, dtype=float)

# Startwerte für den Fit
p0 = [np.max(y), x_fit[np.argmax(y)], (np.max(x_fit) - np.min(x_fit)) / 5]

# Curve-Fit mit transformierten X-Werten
popt, _ = curve_fit(func, x_fit, y, p0=p0)
a_fit, x0_fit, sigma_fit = popt

# Zentrum zurückrechnen auf ursprüngliche Zeilennummer
x0_original_scale = inverse_transform_x(x0_fit)

# Fitkurve erzeugen (auf transformierter Basis, aber für Original x anzeigen)
ym = func(x_fit, *popt)

# ---------- Plot mit originalen Zeilennummern ----------
plt.figure(figsize=(10,5))
plt.bar(x_orig, y, width=0.8, color='skyblue', edgecolor='blue', linewidth=0.8, label='counts')
plt.plot(x_orig, ym, color='orange', linewidth=2, label='Gefittete Gauss-Funktion')
plt.xlabel('x (Stärke Elektrischer Impuls)')
plt.ylabel('y (counts)')
plt.title(f'Gaussian Fit (Zeilen {startzeile}-{endzeile}, X transformiert für Fit)')
plt.legend()
plt.tight_layout()
plt.show()

# Fit-Parameter ausgeben
print("Fit-Parameter (basierend auf transformierter X-Achse):")
print(f"Amplitude (a)     = {a_fit} (counts)")
print(f"Zentrum (x0')     = {x0_fit}  (in keV)")
print(f"Zentrum (Zeile)   = {x0_original_scale}  (Stärke Elektrischer Impuls)")
print(f"Sigma             = {sigma_fit}")

c=299792458
me=9.109*10**(-31)
E=662
EJ=(1.60218*10**(-16))*E
phi=math.radians(120)

Eq=EJ/(1+(EJ/(me*c**2))*(1-math.cos(phi)))
Eg=(6.242*10**(15))*Eq
print("Sollwert=", Eg, "keV")
# ---------- Alle y-Werte im gewählten Zeilenbereich summieren ----------
n = np.sum(y)
print("n(",startzeile,"-",endzeile,")=",n)